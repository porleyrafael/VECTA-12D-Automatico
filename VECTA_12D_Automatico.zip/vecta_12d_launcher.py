#!/usr/bin/env python3
"""
VECTA 12D - LANZADOR PRINCIPAL
Ejecuta VECTA 12D directamente, incluso sin instalación
"""
import os
import sys
import json
import tempfile
import zipfile
from pathlib import Path

class VECTA_Launcher:
    """Lanzador que funciona incluso desde el ZIP"""
    
    def __init__(self):
        self.is_portable = self._check_portable()
        self.vecta_dir = self._get_vecta_dir()
        
    def _check_portable(self):
        """Verifica si estamos en modo portable"""
        return hasattr(sys, '_MEIPASS') or 'pythonw' in sys.executable
    
    def _get_vecta_dir(self):
        """Determina el directorio de VECTA"""
        # 1. Directorio de instalación
        if os.path.exists("VECTA_12D"):
            return Path("VECTA_12D")
        
        # 2. Directorio portable
        if self.is_portable and hasattr(sys, '_MEIPASS'):
            return Path(sys._MEIPASS)
        
        # 3. Directorio del usuario
        user_dir = Path.home() / "VECTA_12D"
        if user_dir.exists():
            return user_dir
        
        # 4. Directorio actual
        return Path.cwd()
    
    def _extract_embedded(self):
        """Extrae archivos embebidos si es necesario"""
        # Si estamos en un ejecutable PyInstaller
        if hasattr(sys, '_MEIPASS'):
            print("📦 Modo ejecutable detectado")
            return True
            
        # Buscar archivo .pkg embebido
        pkg_files = list(Path.cwd().glob("*.pkg"))
        if pkg_files:
            print(f"📦 Extrayendo paquete: {pkg_files[0]}")
            
            # Extraer a directorio temporal
            temp_dir = tempfile.mkdtemp(prefix="vecta_12d_")
            with zipfile.ZipFile(pkg_files[0], 'r') as zip_ref:
                zip_ref.extractall(temp_dir)
            
            self.vecta_dir = Path(temp_dir)
            return True
            
        return False
    
    def check_dependencies(self):
        """Verifica e instala dependencias mínimas"""
        print("🔧 Verificando dependencias...")
        
        try:
            import numpy
            import cryptography
            import psutil
            import requests
            print("✅ Todas las dependencias están instaladas")
            return True
        except ImportError as e:
            print(f"⚠️  Dependencia faltante: {e}")
            
            # Instalar automáticamente
            try:
                import subprocess
                missing = str(e).split("'")[1]
                subprocess.check_call([sys.executable, "-m", "pip", "install", missing])
                print(f"✅ Instalado: {missing}")
                return True
            except:
                print(f"❌ No se pudo instalar {missing}")
                return False
    
    def launch_vecta(self):
        """Lanza VECTA 12D"""
        print(f"🌀 Iniciando VECTA 12D desde: {self.vecta_dir}")
        
        # Añadir al path
        sys.path.insert(0, str(self.vecta_dir))
        sys.path.insert(0, str(self.vecta_dir / "core"))
        sys.path.insert(0, str(self.vecta_dir / "dimensiones"))
        
        try:
            # Importar núcleo
            from core.vecta_12d_core import VECTA_12D_Core
            
            # Crear instancia
            vecta = VECTA_12D_Core()
            
            print("\n" + "="*50)
            print("   🌀 VECTA 12D - SISTEMA ACTIVO")
            print("   Modo: Autoprogramable de 12 Dimensiones")
            print("="*50)
            
            # Iniciar interfaz
            if hasattr(vecta, 'start_gui'):
                vecta.start_gui()
            else:
                self._start_text_interface(vecta)
                
        except ImportError as e:
            print(f"❌ Error importando módulos: {e}")
            print("\nPosibles soluciones:")
            print("1. Ejecuta el instalador: python vecta_self_install.py")
            print("2. Verifica que todos los archivos estén presentes")
            input("\nPresiona Enter para salir...")
    
    def _start_text_interface(self, vecta):
        """Interfaz de texto si no hay GUI"""
        print("\n📟 Modo Consola 12D")
        print("Comandos disponibles:")
        print("  /programar [descripción] - Auto-programa una función")
        print("  /dimensiones - Muestra estado de las 12 dimensiones")
        print("  /actualizar - Busca actualizaciones")
        print("  /configurar - Configura claves API")
        print("  /salir - Cierra VECTA")
        print("-"*50)
        
        while True:
            try:
                user_input = input("\n12D> ").strip()
                
                if not user_input:
                    continue
                    
                if user_input.lower() in ['/salir', '/exit', '/quit']:
                    print("👋 Cerrando VECTA 12D...")
                    break
                    
                elif user_input.lower() == '/dimensiones':
                    self._show_dimensions(vecta)
                    
                elif user_input.startswith('/programar '):
                    description = user_input[11:]
                    print(f"🧠 Auto-programando: {description}")
                    # Aquí iría la lógica de autoprogramación
                    
                elif user_input.lower() == '/configurar':
                    self._configure_api_keys()
                    
                elif user_input.lower() == '/actualizar':
                    print("🔍 Buscando actualizaciones...")
                    # Aquí iría la lógica de actualización
                    
                else:
                    # Procesar como comando normal
                    response = vecta.process(user_input)
                    print(f"VECTA: {response}")
                    
            except KeyboardInterrupt:
                print("\n🛑 Interrumpido por usuario")
                break
            except Exception as e:
                print(f"❌ Error: {e}")
    
    def _show_dimensions(self, vecta):
        """Muestra estado de las dimensiones"""
        if hasattr(vecta, 'get_dimension_status'):
            status = vecta.get_dimension_status()
            for dim, info in status.items():
                print(f"{dim}: {info['status']} - {info['description']}")
        else:
            print("📊 Dimensiones 12D del sistema:")
            dimensions = [
                "1️⃣  Temporal: Secuencias y tiempo",
                "2️⃣  Espacial: Relaciones espaciales",
                "3️⃣  Lógica: Razonamiento lógico",
                "4️⃣  Semántica: Significado y contexto",
                "5️⃣  Emocional: Tono y sentimiento",
                "6️⃣  Contextual: Entorno y situación",
                "7️⃣  Evolutiva: Aprendizaje y mejora",
                "8️⃣  Relacional: Conexiones y redes",
                "9️⃣  Energética: Flujo y potencia",
                "🔟  Cuántica: Superposición y probabilidad",
                "1️⃣1️⃣ Holográfica: Todo en cada parte",
                "1️⃣2️⃣ Unitaria: Unidad y totalidad"
            ]
            for dim in dimensions:
                print(f"  {dim}")
    
    def _configure_api_keys(self):
        """Configura claves API de forma segura"""
        print("\n🔐 Configuración de Claves API")
        print("Servicios disponibles:")
        print("  openai - OpenAI GPT (opcional)")
        print("  deepseek - DeepSeek AI (opcional)")
        print("  anthropic - Claude AI (opcional)")
        print("\n¿Qué servicio quieres configurar? (dejar vacío para cancelar)")
        
        service = input("Servicio: ").strip().lower()
        if not service:
            return
            
        key = input(f"Clave API para {service}: ").strip()
        
        if key:
            # Guardar de forma segura
            try:
                from core.vecta_secure_config import SecureKeyManager
                manager = SecureKeyManager()
                success, message = manager.save_api_key(service, key)
                print(f"✅ {message}")
            except:
                print("⚠️  No se pudo guardar la clave. El sistema funcionará en modo local.")
    
    def run(self):
        """Ejecuta el lanzador completo"""
        print("\n" + "="*50)
        print("   🚀 VECTA 12D - LANZADOR AUTO-CONTENIDO")
        print("="*50)
        
        # Extraer si es necesario
        if not self.vecta_dir.exists():
            if not self._extract_embedded():
                print("❌ No se encontró la instalación de VECTA 12D")
                print("\nEjecuta primero: python vecta_self_install.py")
                input("\nPresiona Enter para salir...")
                return
        
        # Verificar dependencias
        if not self.check_dependencies():
            print("⚠️  Algunas dependencias faltan, continuando en modo limitado...")
        
        # Lanzar VECTA
        self.launch_vecta()

def main():
    """Punto de entrada principal"""
    launcher = VECTA_Launcher()
    launcher.run()

if __name__ == "__main__":
    main()